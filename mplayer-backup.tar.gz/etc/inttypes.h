
// fallback if the user doesn't have inttypes.h (libc5 systems)

#include <sys/bitypes.h>
