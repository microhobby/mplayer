Document: mplayer-pl
Title: MPlayer documentation (Polish)
Author: The MPlayer team
Abstract: This documentation describes the use of MPlayer. (Polish)
 MPlayer is a movie player for GNU/Linux that supports a wide
 range of audio and video formats, and output drivers.
Section: Sound

Format: HTML
Index: /usr/share/doc/mplayer-doc/HTML/pl/index.html
Files: /usr/share/doc/mplayer-doc/HTML/pl/*.html
